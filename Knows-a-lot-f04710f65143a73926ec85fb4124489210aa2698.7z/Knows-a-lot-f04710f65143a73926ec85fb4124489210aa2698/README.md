# Knows-a-lot

## Collaborators
- Jay Tinosa
- Mark Daniel Igne
- Zennon Santos
- Alexandra Lagumen
- John Vic Dagoc

## Design
- [Figma Design](https://www.figma.com/file/up1pYJgs3z4ynWJIa6uMLI/Knows-a-lot?type=design&mode=design&t=uzG7JhkiI35AG36B-0)
