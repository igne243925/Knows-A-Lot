package com.jtdev.knowsalot;

import android.app.Activity;

public class CreateQuestionScreen extends Activity {
}
